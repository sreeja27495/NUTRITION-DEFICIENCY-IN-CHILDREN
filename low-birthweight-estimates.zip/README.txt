GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Low birthweight estimates
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/low-birthweight-estimates
	Description: 
	Nutrition is a critical part of health and development. Better nutrition is related to improved infant, child and maternal health, stronger immune systems, safer pregnancy and childbirth, lower risk of non-communicable diseases (such as diabetes and cardiovascular disease), and longevity.Healthy children learn better. People with adequate nutrition are more productive and can create opportunities to gradually break the cycles of poverty and hunger.Malnutrition, in every form, presents significant threats to human health. Today the world faces a double burden of malnutrition that includes both undernutrition and overweight, especially in low- and middle-income countries.
	
	Date generated: 2023-12-11

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Low birthweight estimates"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: gho-nutrition
	self: low-birthweight-estimates
	children: 
		LBW_NUMBER	Low birthweight number (in thousands)
		LBW_PREVALENCE	Low birthweight prevalence (%)
		PRETERMBIRTH_RATE	Preterm birth rate per 100 live births
		PRETERMBIRTH_NUMBER	Preterm births (number)
	
